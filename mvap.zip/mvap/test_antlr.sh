antlr4 mvaptp.g4
javac ./*.java -cp .:/usr/local/java/antlr-4.4-complete.jar
grun mvaptp start input